function mlToOz(amount) {
  return amount * 0.033814
}

function ozToMl(amount) {
  return amount * 29.5735
}

module.exports = { mlToOz, ozToMl }
